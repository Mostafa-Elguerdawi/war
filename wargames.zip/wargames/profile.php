<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$iid = $_SESSION['user_id'];

// Database connection
$servername = "localhost";
$db_username = "root"; // replace with your database username
$db_password = ""; // replace with your database password
$dbname = "wargames"; // replace with your database name

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection and handle SQL errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['error'])) {
    echo "SQL Error: " . htmlspecialchars($_GET['error']);
}

$uu = $_SESSION['username'];

// Use a prepared statement to prevent SQL injection
$stmt = $conn->prepare("SELECT email FROM users WHERE username = ?");
$stmt->bind_param("s", $uu);
$stmt->execute();
$stmt->bind_result($email);
$stmt->fetch();
$stmt->close();

$_SESSION['email'] = $email;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $target_dir = "uploads/";
    $file_name = basename($_FILES["file"]["name"]);
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $random_name = uniqid() . "." . $file_ext;
    $target_file = $target_dir . $random_name;

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO files (id, file_path) VALUES ('$iid', '$target_file')ON DUPLICATE KEY UPDATE file_path='$target_file'";
        //$sql = "UPDATE files SET file_path = '$target_file' WHERE id = $iid";
        if ($conn->query($sql) === FALSE) {
            header("Location: profile.php?error=" . $conn->error);
            exit;
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 8px;
            width: 400px;
            text-align: center;
        }
        h1 {
            margin-bottom: 20px;
        }
        .file-upload {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
        <?php
        if (isset($_GET['error'])) {
            echo "<p>SQL Error: " . $_GET['error'] . "</p>";
        }
        ?>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="file-upload">
                <label for="file">Upload a file:</label>
                <input type="file" id="file" name="file" required>
            </div>
            <button type="submit">Upload</button>
        </form>
    </div>
</body>
</html>
    <p>Your Email is <?php echo htmlspecialchars($_SESSION['email']); ?>!</p>
    <p>Your ID is <?php echo htmlspecialchars($_SESSION['user_id']); ?>!</p>
    <!-- Add any profile content here -->
</body>
</html>
