<?php
session_start();

// Function to sanitize input data
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Database connection
$servername = "localhost";
$db_username = "root"; // replace with your database username
$db_password = ""; // replace with your database password
$dbname = "wargames"; // replace with your database name

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$errors = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $username = $_POST["username"];
    $email = sanitize_input($_POST["email"]);
    $password = sanitize_input($_POST["password"]);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if any of the fields are empty
    if (empty($username) || empty($email) || empty($password)) {
        $errors[] = "All fields are required.";
    } else {
        // Check if username or email already exists
        //$sql = "SELECT id FROM users WHERE username = '$username' OR email = '$email'";
        //$result = $conn->query($sql);

        
            $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

            $insert_result = $conn->query($sql);
            if ($insert_result === false) {
                $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
                $insert_result = $conn->query($sql);
            } else {
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['username'] = $username;
                //$_SESSION['email'] = $email;
                header("Location: login.php");
                exit;
            }
        }
    }


$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Sign Up</title>
</head>
<body>
    <h2>Sign Up</h2>
    <?php
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p>Error: $error</p>";
        }
    }
    ?>
    <form action="" method="POST">
        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Sign Up</button>
    </form>
</body>
</html>
